# CART3R SNIPER PRO

Website and Python API for an educational ICT-inspired market scanner.

## Upload this project
Extract the ZIP and upload the **contents** into the root of `Komkheth/AI-SIGNAL`. The repository root should contain `website/`, `backend/`, `render.yaml`, and `.github/workflows/pages.yml`.

## GitHub Pages
After upload, open **Settings → Pages** and choose **GitHub Actions** as the build/deployment source. The included workflow deploys `website/` on pushes to `main`.

## Render API
In Render choose **New → Blueprint**, connect `Komkheth/AI-SIGNAL`, and let Render read `render.yaml`. The blueprint uses `backend/` as its root and runs:

- Build: `pip install -r requirements.txt`
- Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

Add these secrets in the Render service Environment page, not in GitHub:

- `TWELVE_DATA_API_KEY`
- `FINNHUB_API_KEY`
- `OPENAI_API_KEY`
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Keep `SCAN_ENABLED=false` and `TELEGRAM_ENABLED=false` during initial verification. Test `/health`, `/api/config`, `/api/news`, `/api/candles?symbol=BTCUSD&timeframe=5m`, and `/api/assistant/chat`. Then add the Render service URL to the website's **Backend API URL** field and press **Connect backend**.

Only enable scanning and Telegram after verifying provider quotas and successful test alerts. Free Render instances may sleep while idle and are not suitable for dependable always-on alerts; review the current plan limits.

## Known limitations
- Signal logic is a simplified ICT-inspired candidate detector, not a complete institutional ICT model.
- News bias is a simple keyword heuristic, not a verified market-impact forecast or economic calendar.
- Signal history is in memory and resets when the service restarts.
- BTCUSD uses Binance BTCUSDT candles as a proxy.
- No broker integration or automatic order execution is included.
- Signals are educational candidates, not guaranteed outcomes. Paper-test before any live trading.
