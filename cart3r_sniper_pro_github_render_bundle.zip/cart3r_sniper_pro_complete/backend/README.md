# CART3R SNIPER PRO — Live Signal Backend

A Python/FastAPI backend starter for Forex, Gold (XAUUSD), and Bitcoin (BTCUSD) candidate signals on M1/M5/M15. It uses Twelve Data for Forex/metals candles and Binance public klines for BTCUSDT market data. Telegram notifications are optional.

**No broker integration, order endpoint, or automatic trade execution is included.**

## Strategy logic included
The rule-based ICT-inspired detector checks the latest fully closed candle for:
1. A liquidity sweep of the preceding range high/low followed by a close back inside.
2. Displacement body relative to ATR.
3. A local BOS-style close beyond a recent swing high/low.
4. A three-candle FVG.
5. An approximate order block (last opposing candle in a short lookback).
6. A candidate entry at the FVG midpoint, invalidation beyond sweep/OB, and configurable minimum reward:risk.

This is a deliberately simplified, testable starting point, not a complete or authoritative implementation of ICT. The `FVG_MAX_AGE` setting is reserved for a future retest-state implementation; this starter currently requires the latest closed candle to form the FVG. It does not implement premium/discount, session filters, higher-timeframe bias, spread filters, or actual FVG/OB retest state. Signals are candidates and must be independently validated.

## Providers
- Twelve Data `/time_series`: EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CAD, XAU/USD. A Twelve Data API key is required.
- Binance `/api/v3/klines`: BTCUSDT is used as the BTCUSD proxy. This is exchange BTCUSDT pricing, not necessarily the same as a broker's BTCUSD CFD.

Check provider symbol support, plan limits, and terms before production use. Twelve Data API quotas may make scanning all symbols/timeframes every few minutes impractical on a free tier.

## Local setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
Edit `.env` and set `TWELVE_DATA_API_KEY`. For Telegram, create a bot with BotFather, add it to the target chat, obtain the chat ID, then set:
```env
TELEGRAM_ENABLED=true
TELEGRAM_BOT_TOKEN=your_token
TELEGRAM_CHAT_ID=your_chat_id
```
Never commit `.env`. Never put tokens in browser JavaScript.

Start API:
```bash
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Open API docs at `http://127.0.0.1:8000/docs`.

## API endpoints
- `GET /health` — status; explicitly reports execution disabled.
- `GET /api/config` — supported symbols/timeframes and feature flags.
- `GET /api/candles?symbol=EURUSD&timeframe=5m&limit=200`
- `POST /api/scan?symbol=XAUUSD&timeframe=15m`
- `GET /api/signals?symbol=BTCUSD&timeframe=1m&limit=50`

Set `SCAN_ENABLED=true` to enable background scanning. It starts disabled by default. The background worker scans all configured symbols/timeframes sequentially; adjust interval to respect provider quotas. Telegram alerts only send when a new signal candidate is detected and cooldown permits.

## Connect the website
Set the frontend's API base URL to your deployed backend, then request `/api/signals` and poll at a sensible interval (e.g. 15–30 seconds). Configure CORS in `app/main.py` to allow only your deployed website origin before public deployment.

## Deploy
Docker:
```bash
docker build -t cart3r-sniper-api .
docker run --env-file .env -p 8000:8000 cart3r-sniper-api
```
Use a managed server/container host with HTTPS, secret environment variables, logs, rate limiting, and monitoring. Do not expose the API publicly without access controls/rate limiting if you add paid or private signal features.

## Safety
This backend does not place trades and has no broker/exchange trading keys. Signals are not financial advice or guaranteed. Validate data quality, backtest with realistic spread/slippage/fees, and paper-trade before relying on alerts. The current signal list is in-memory and resets on restart; add a database before production.

## News feed + AI chat (added)
Optional live news is provided by Finnhub's market-news endpoint. Add `FINNHUB_API_KEY` to the server `.env` to enable `GET /api/news?category=general`. The feed shows headline, source, summary, and a deliberately rough keyword-based bullish/bearish/mixed label. This label is not a validated sentiment model and should never be treated as a standalone trade signal.

The AI chat endpoint is `POST /api/assistant/chat` with JSON such as:
```json
{"question":"Explain the latest BTC headlines alongside the recent ICT setup","symbol":"BTCUSD","timeframe":"5m"}
```
Add `OPENAI_API_KEY` (and optionally `OPENAI_MODEL`) to enable it. The server sends recent news and recent in-memory signal candidates as context. The API key stays on the backend; never place it in frontend JavaScript. If either key is missing, the corresponding feature reports that it is not configured.

The updated website includes a backend URL field, live news panel, signal feed connection, and AI chat panel. Paste the deployed API base URL into the website and press **Connect backend**. Deploy the backend with both provider keys configured to enable the complete experience. Provider plans, quotas, data rights, and API terms apply.
